import { useState } from "react";
import { Link } from "react-router";
import { Search, Plus, ArrowUpDown, X, FileQuestion } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { mockProviders } from "../utils/mockData";
import type { Provider } from "../types";

type SortField = "name" | "lastVerified" | "status" | "serviceType";
type SortDirection = "asc" | "desc";

export function ProviderDirectory() {
  const [providers] = useState<Provider[]>(mockProviders);
  const [searchQuery, setSearchQuery] = useState("");
  const [serviceTypeFilter, setServiceTypeFilter] = useState("all");
  const [locationFilter, setLocationFilter] = useState("all");
  const [costFilter, setCostFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortField, setSortField] = useState<SortField>("name");
  const [sortDirection, setSortDirection] = useState<SortDirection>("asc");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const getStatusBadge = (status: Provider["status"]) => {
    const variants = {
      verified: { className: "bg-green-100 text-green-800 border-green-200", label: "Verified" },
      pending: { className: "bg-yellow-100 text-yellow-800 border-yellow-200", label: "Pending Review" },
      "needs-update": { className: "bg-red-100 text-red-800 border-red-200", label: "Needs Update" },
      archived: { className: "bg-gray-100 text-gray-800 border-gray-200", label: "Archived" },
    };
    const variant = variants[status];
    return (
      <Badge className={`${variant.className} border`} variant="outline">
        {variant.label}
      </Badge>
    );
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const clearFilters = () => {
    setSearchQuery("");
    setServiceTypeFilter("all");
    setLocationFilter("all");
    setCostFilter("all");
    setStatusFilter("all");
    setCurrentPage(1);
  };

  const hasActiveFilters =
    searchQuery !== "" ||
    serviceTypeFilter !== "all" ||
    locationFilter !== "all" ||
    costFilter !== "all" ||
    statusFilter !== "all";

  const filteredProviders = providers.filter((provider) => {
    const matchesSearch =
      searchQuery === "" ||
      provider.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      provider.serviceType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      provider.location.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesServiceType = serviceTypeFilter === "all" || provider.serviceType === serviceTypeFilter;
    const matchesLocation = locationFilter === "all" || provider.zip === locationFilter;
    const matchesCost =
      costFilter === "all" ||
      (costFilter === "free" && provider.cost.toLowerCase().includes("free")) ||
      (costFilter === "sliding" && provider.cost.toLowerCase().includes("sliding")) ||
      (costFilter === "paid" && !provider.cost.toLowerCase().includes("free") && !provider.cost.toLowerCase().includes("sliding"));
    const matchesStatus = statusFilter === "all" || provider.status === statusFilter;

    return matchesSearch && matchesServiceType && matchesLocation && matchesCost && matchesStatus;
  });

  const sortedProviders = [...filteredProviders].sort((a, b) => {
    let comparison = 0;
    switch (sortField) {
      case "name":
        comparison = a.name.localeCompare(b.name);
        break;
      case "lastVerified":
        comparison = new Date(a.lastVerified).getTime() - new Date(b.lastVerified).getTime();
        break;
      case "status":
        comparison = a.status.localeCompare(b.status);
        break;
      case "serviceType":
        comparison = a.serviceType.localeCompare(b.serviceType);
        break;
    }
    return sortDirection === "asc" ? comparison : -comparison;
  });

  const totalPages = Math.ceil(sortedProviders.length / itemsPerPage);
  const paginatedProviders = sortedProviders.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const lastSyncTime = new Date().toLocaleString();

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-3xl font-semibold text-gray-900">Provider Directory</h1>
        </div>
        <div className="bg-blue-50 border border-blue-200 rounded-lg px-4 py-2 text-sm text-blue-800">
          Last directory sync with chat interface: {lastSyncTime}
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1 max-w-md relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" aria-hidden="true" />
            <Input
              type="search"
              placeholder="Search providers by name, service type, or location"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              className="pl-10"
              aria-label="Search providers by name, service type, or location"
            />
          </div>
          <Link to="/providers/new">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="w-4 h-4 mr-2" aria-hidden="true" />
              Add New Provider
            </Button>
          </Link>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label htmlFor="service-type-filter" className="block text-sm font-medium text-gray-700 mb-1">
              Service Type
            </label>
            <Select
              value={serviceTypeFilter}
              onValueChange={(value) => {
                setServiceTypeFilter(value);
                setCurrentPage(1);
              }}
            >
              <SelectTrigger id="service-type-filter" aria-label="Filter by service type">
                <SelectValue placeholder="All types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                <SelectItem value="evaluator">Evaluator</SelectItem>
                <SelectItem value="tutor">Tutor</SelectItem>
                <SelectItem value="advocate">Advocate</SelectItem>
                <SelectItem value="therapist">Therapist</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label htmlFor="location-filter" className="block text-sm font-medium text-gray-700 mb-1">
              Location/ZIP
            </label>
            <Select
              value={locationFilter}
              onValueChange={(value) => {
                setLocationFilter(value);
                setCurrentPage(1);
              }}
            >
              <SelectTrigger id="location-filter" aria-label="Filter by location or ZIP code">
                <SelectValue placeholder="All locations" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All locations</SelectItem>
                <SelectItem value="90001">90001 - Los Angeles</SelectItem>
                <SelectItem value="92101">92101 - San Diego</SelectItem>
                <SelectItem value="94601">94601 - Oakland</SelectItem>
                <SelectItem value="94102">94102 - San Francisco</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label htmlFor="cost-filter" className="block text-sm font-medium text-gray-700 mb-1">
              Cost Range
            </label>
            <Select
              value={costFilter}
              onValueChange={(value) => {
                setCostFilter(value);
                setCurrentPage(1);
              }}
            >
              <SelectTrigger id="cost-filter" aria-label="Filter by cost range">
                <SelectValue placeholder="All costs" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All costs</SelectItem>
                <SelectItem value="free">Free</SelectItem>
                <SelectItem value="sliding">Sliding scale</SelectItem>
                <SelectItem value="paid">Paid services</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label htmlFor="status-filter" className="block text-sm font-medium text-gray-700 mb-1">
              Verification Status
            </label>
            <Select
              value={statusFilter}
              onValueChange={(value) => {
                setStatusFilter(value);
                setCurrentPage(1);
              }}
            >
              <SelectTrigger id="status-filter" aria-label="Filter by verification status">
                <SelectValue placeholder="All statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                <SelectItem value="verified">Verified</SelectItem>
                <SelectItem value="pending">Pending Review</SelectItem>
                <SelectItem value="needs-update">Needs Update</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {hasActiveFilters && (
          <div className="mt-4 flex items-center justify-between">
            <p className="text-sm text-gray-600">
              Showing {sortedProviders.length} of {providers.length} providers
            </p>
            <Button variant="outline" size="sm" onClick={clearFilters}>
              <X className="w-4 h-4 mr-2" aria-hidden="true" />
              Clear Filters
            </Button>
          </div>
        )}
      </div>

      {/* Provider Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-50">
              <TableHead className="font-semibold text-gray-900">
                <button
                  onClick={() => handleSort("name")}
                  className="flex items-center gap-1 hover:text-blue-600"
                  aria-label="Sort by provider name"
                >
                  Provider Name
                  <ArrowUpDown className="w-4 h-4" aria-hidden="true" />
                </button>
              </TableHead>
              <TableHead className="font-semibold text-gray-900">
                <button
                  onClick={() => handleSort("serviceType")}
                  className="flex items-center gap-1 hover:text-blue-600"
                  aria-label="Sort by service type"
                >
                  Service Type
                  <ArrowUpDown className="w-4 h-4" aria-hidden="true" />
                </button>
              </TableHead>
              <TableHead className="font-semibold text-gray-900">Location</TableHead>
              <TableHead className="font-semibold text-gray-900">Cost</TableHead>
              <TableHead className="font-semibold text-gray-900">
                <button
                  onClick={() => handleSort("lastVerified")}
                  className="flex items-center gap-1 hover:text-blue-600"
                  aria-label="Sort by last verified date"
                >
                  Last Verified
                  <ArrowUpDown className="w-4 h-4" aria-hidden="true" />
                </button>
              </TableHead>
              <TableHead className="font-semibold text-gray-900">
                <button
                  onClick={() => handleSort("status")}
                  className="flex items-center gap-1 hover:text-blue-600"
                  aria-label="Sort by status"
                >
                  Status
                  <ArrowUpDown className="w-4 h-4" aria-hidden="true" />
                </button>
              </TableHead>
              <TableHead className="font-semibold text-gray-900">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedProviders.length === 0 && !hasActiveFilters && (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-12">
                  <div className="flex flex-col items-center gap-3">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                      <FileQuestion className="w-8 h-8 text-gray-400" aria-hidden="true" />
                    </div>
                    <div>
                      <p className="text-lg font-medium text-gray-900">No providers yet</p>
                      <p className="text-sm text-gray-500 mt-1">Get started by adding your first provider</p>
                    </div>
                    <Link to="/providers/new">
                      <Button className="mt-2 bg-blue-600 hover:bg-blue-700 text-white">
                        <Plus className="w-4 h-4 mr-2" aria-hidden="true" />
                        Add New Provider
                      </Button>
                    </Link>
                  </div>
                </TableCell>
              </TableRow>
            )}

            {paginatedProviders.length === 0 && hasActiveFilters && (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-12">
                  <div className="flex flex-col items-center gap-3">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                      <Search className="w-8 h-8 text-gray-400" aria-hidden="true" />
                    </div>
                    <div>
                      <p className="text-lg font-medium text-gray-900">No providers found</p>
                      <p className="text-sm text-gray-500 mt-1">Try adjusting your filters or search query</p>
                    </div>
                    <Button variant="outline" onClick={clearFilters} className="mt-2">
                      <X className="w-4 h-4 mr-2" aria-hidden="true" />
                      Clear Filters
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            )}

            {paginatedProviders.map((provider) => (
              <TableRow key={provider.id} className="hover:bg-gray-50">
                <TableCell>
                  <Link
                    to={`/providers/${provider.id}`}
                    className="font-medium text-blue-600 hover:text-blue-800 hover:underline"
                  >
                    {provider.name}
                  </Link>
                  {provider.organization && (
                    <div className="text-sm text-gray-500">{provider.organization}</div>
                  )}
                </TableCell>
                <TableCell className="capitalize">{provider.serviceType}</TableCell>
                <TableCell>
                  {provider.location}
                  <div className="text-sm text-gray-500">{provider.zip}</div>
                </TableCell>
                <TableCell>{provider.cost}</TableCell>
                <TableCell>{new Date(provider.lastVerified).toLocaleDateString()}</TableCell>
                <TableCell>{getStatusBadge(provider.status)}</TableCell>
                <TableCell>
                  <Link to={`/providers/${provider.id}`}>
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </Link>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="mt-6 flex items-center justify-between">
          <p className="text-sm text-gray-600">
            Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
            {Math.min(currentPage * itemsPerPage, sortedProviders.length)} of {sortedProviders.length} providers
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
            >
              Previous
            </Button>
            <div className="flex items-center gap-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={page === currentPage ? "default" : "outline"}
                  size="sm"
                  onClick={() => setCurrentPage(page)}
                  className={page === currentPage ? "bg-blue-600 hover:bg-blue-700 text-white" : ""}
                  aria-label={`Go to page ${page}`}
                  aria-current={page === currentPage ? "page" : undefined}
                >
                  {page}
                </Button>
              ))}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
