import { Link } from "react-router";
import { Users, CheckCircle, Clock, AlertTriangle, TrendingUp } from "lucide-react";
import { Button } from "./ui/button";

export function Dashboard() {
  const stats = [
    {
      label: "Total Providers",
      value: "124",
      icon: Users,
      color: "bg-blue-100 text-blue-600",
      change: "+12 this month",
    },
    {
      label: "Verified Providers",
      value: "98",
      icon: CheckCircle,
      color: "bg-green-100 text-green-600",
      change: "79% of total",
    },
    {
      label: "Pending Review",
      value: "18",
      icon: Clock,
      color: "bg-yellow-100 text-yellow-600",
      change: "Needs attention",
    },
    {
      label: "Needs Update",
      value: "8",
      icon: AlertTriangle,
      color: "bg-red-100 text-red-600",
      change: "Requires action",
    },
  ];

  const recentActivity = [
    {
      action: "Added new provider",
      provider: "Dr. Sarah Johnson",
      time: "2 hours ago",
      user: "Staff Admin",
    },
    {
      action: "Verified provider",
      provider: "Maria Rodriguez",
      time: "5 hours ago",
      user: "Jane Smith",
    },
    {
      action: "Updated information",
      provider: "Community Advocacy Center",
      time: "1 day ago",
      user: "Staff Admin",
    },
    {
      action: "Flagged for review",
      provider: "Dr. Michael Chen",
      time: "2 days ago",
      user: "John Doe",
    },
  ];

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-gray-900 mb-2">Dashboard</h1>
        <p className="text-gray-600">Welcome back! Here's an overview of your provider directory.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-lg ${stat.color} flex items-center justify-center`}>
                  <Icon className="w-6 h-6" aria-hidden="true" />
                </div>
              </div>
              <p className="text-sm font-medium text-gray-500 mb-1">{stat.label}</p>
              <p className="text-3xl font-semibold text-gray-900 mb-2">{stat.value}</p>
              <p className="text-sm text-gray-600">{stat.change}</p>
            </div>
          );
        })}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activity */}
        <div className="lg:col-span-2 bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Recent Activity</h2>
            <Link to="/providers" className="text-sm text-blue-600 hover:text-blue-800">
              View all
            </Link>
          </div>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div
                key={index}
                className="flex items-start gap-4 pb-4 border-b border-gray-200 last:border-0 last:pb-0"
              >
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-900">
                    <span className="font-medium">{activity.user}</span> {activity.action}:{" "}
                    <span className="font-medium">{activity.provider}</span>
                  </p>
                  <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="space-y-6">
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
            <div className="space-y-3">
              <Link to="/providers">
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white justify-start">
                  <Users className="w-4 h-4 mr-2" aria-hidden="true" />
                  View All Providers
                </Button>
              </Link>
              <Link to="/providers/new">
                <Button variant="outline" className="w-full justify-start">
                  <TrendingUp className="w-4 h-4 mr-2" aria-hidden="true" />
                  Add New Provider
                </Button>
              </Link>
              <Link to="/pending-reviews">
                <Button variant="outline" className="w-full justify-start">
                  <Clock className="w-4 h-4 mr-2" aria-hidden="true" />
                  Review Pending ({18})
                </Button>
              </Link>
              <Link to="/import-export">
                <Button variant="outline" className="w-full justify-start">
                  <TrendingUp className="w-4 h-4 mr-2" aria-hidden="true" />
                  Import/Export Data
                </Button>
              </Link>
            </div>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <h3 className="font-semibold text-green-900 mb-2 flex items-center gap-2">
              <CheckCircle className="w-4 h-4" aria-hidden="true" />
              System Status
            </h3>
            <p className="text-sm text-green-800 mb-2">
              All systems operational
            </p>
            <p className="text-xs text-green-700">
              Last sync: {new Date().toLocaleString()}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}