import { Outlet, Link, useLocation } from "react-router";
import { Home, Users, Clock, Settings as SettingsIcon, User, FileText, Upload } from "lucide-react";

export function AdminLayout() {
  const location = useLocation();

  const isActive = (path: string) => {
    if (path === "/") {
      return location.pathname === "/";
    }
    return location.pathname.startsWith(path);
  };

  const navItems = [
    { path: "/", label: "Dashboard", icon: Home },
    { path: "/providers", label: "Provider Directory", icon: Users },
    { path: "/pending-reviews", label: "Pending Reviews", icon: Clock },
    { path: "/audit-log", label: "Audit Log", icon: FileText },
    { path: "/import-export", label: "Import/Export", icon: Upload },
    { path: "/settings", label: "Settings", icon: SettingsIcon },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-800 text-white flex flex-col">
        <div className="p-6 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded flex items-center justify-center font-bold text-lg">
              L
            </div>
            <div>
              <h1 className="font-semibold text-lg">LDAPA</h1>
              <p className="text-xs text-gray-400">Provider Directory</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4" aria-label="Main navigation">
          <ul className="space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.path);
              return (
                <li key={item.path}>
                  <Link
                    to={item.path}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      active
                        ? "bg-blue-600 text-white"
                        : "text-gray-300 hover:bg-gray-700 hover:text-white"
                    }`}
                    aria-current={active ? "page" : undefined}
                  >
                    <Icon className="w-5 h-5" aria-hidden="true" />
                    <span>{item.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="p-4 border-t border-gray-700">
          <div className="flex items-center gap-3 px-4 py-2">
            <User className="w-5 h-5 text-gray-400" aria-hidden="true" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">Staff Admin</p>
              <p className="text-xs text-gray-400">admin@ldapa.org</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}