import { createBrowserRouter } from "react-router";
import { AdminLayout } from "./components/AdminLayout";
import { Dashboard } from "./components/Dashboard";
import { ProviderDirectory } from "./components/ProviderDirectory";
import { ProviderDetail } from "./components/ProviderDetail";
import { AddEditProviderForm } from "./components/AddEditProviderForm";
import { PendingReviews } from "./components/PendingReviews";
import { AuditLog } from "./components/AuditLog";
import { BulkImportExport } from "./components/BulkImportExport";
import { Settings } from "./components/Settings";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: AdminLayout,
    children: [
      { index: true, Component: Dashboard },
      { path: "providers", Component: ProviderDirectory },
      { path: "providers/new", Component: AddEditProviderForm },
      { path: "providers/:id", Component: ProviderDetail },
      { path: "providers/:id/edit", Component: AddEditProviderForm },
      { path: "pending-reviews", Component: PendingReviews },
      { path: "audit-log", Component: AuditLog },
      { path: "import-export", Component: BulkImportExport },
      { path: "settings", Component: Settings },
    ],
  },
]);