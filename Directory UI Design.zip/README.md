
  # Directory UI Design

  This is a code bundle for Directory UI Design. The original project is available at https://www.figma.com/design/45KlIHp4mcla9NUYLXeIFT/Directory-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  